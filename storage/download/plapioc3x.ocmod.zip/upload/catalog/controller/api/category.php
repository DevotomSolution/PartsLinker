<?php
class ControllerApiCategory extends Controller {
	public function list() {
		$json = array();
		
		if (!isset($this->session->data['api_id'])) {
			$json['error'] = 'You do not have permission to access the API!';
		} else {
			$this->load->model('catalog/category');
			
			$json['categories'] = $this->getCategories();
			$json['success'] = 'Success';
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function add() {
		$json = array();
		
		if (!isset($this->session->data['api_id'])) {
			$json['error'] = 'You do not have permission to access the API!';
		} else {
			$input_json = file_get_contents('php://input');

			$post = json_decode($input_json, true);
			
			if($this->validate($post)) {
				$languages = $this->getLanguages();
			
				foreach ($languages as $language) {
					if (isset($post['category_description'][$language['code']]['name'])) {
						$data['category_description'][$language['language_id']]['name'] = $post['category_description'][$language['code']]['name'];
						$data['category_description'][$language['language_id']]['meta_title'] = $post['category_description'][$language['code']]['name'];
						$data['category_description'][$language['language_id']]['meta_keyword'] = $post['category_description'][$language['code']]['name'];
					} else {
						$data['category_description'][$language['language_id']]['name'] = $post['category_description']['en-gb']['name'];
						$data['category_description'][$language['language_id']]['meta_title'] = $post['category_description']['en-gb']['name'];
						$data['category_description'][$language['language_id']]['meta_keyword'] = $post['category_description']['en-gb']['name'];
					}
				}

				if (isset($post['parent_id'])) {
					$data['parent_id'] = $post['parent_id'];
				} else {
					$data['parent_id'] = 0;
				}
				
				if (isset($post['category_filter'])) {
					$data['category_filter'] = $post['category_filter'];
				} else {
					$data['category_filter'] = array();
				}

				$data['category_store'] = array((int) $this->config->get('config_store_id'));

				if (isset($post['top'])) {
					$data['top'] = $post['top'];
				} else {
					$data['top'] = 1;
				}

				if (isset($post['column'])) {
					$data['column'] = $post['column'];
				} else {
					$data['column'] = 1;
				}

				if (isset($post['sort_order'])) {
					$data['sort_order'] = $post['sort_order'];
				} else {
					$data['sort_order'] = 0;
				}

				if (isset($post['status'])) {
					$data['status'] = $post['status'];
				} else {
					$data['status'] = true;
				}

				if (isset($post['category_layout'])) {
					$data['category_layout'] = $post['category_layout'];
				} else {
					$data['category_layout'] = array();
				}
				
				if (!file_exists('image/catalog/category') and file_exists('image/catalog')) {
					mkdir('image/catalog/category');
				}

				$entities = array(' ');
				$replacements = array('%20');
				
				if (isset($post['image']) and file_exists('image/catalog/category')) {
					$pathinfo = pathinfo($post['image']);
					
					if ($pathinfo['extension'] === 'png' or $pathinfo['extension'] === 'jpg' or $pathinfo['extension'] === 'jpeg') {
						$fname = 'image/catalog/category/' . $pathinfo['basename'];
						
						if ($this->CURLLoad(str_replace($entities, $replacements, $post['image']), $fname)) {
							$data['image'] = 'catalog/category/' . $pathinfo['basename'];
						}
					}
				}
				
				$category_id = $this->addCategory($data);

				if ($category_id) {
					$json['category_id'] = $category_id;
					$json['success'] = 'Success';
				} else {
					$json['error'] = 'Warning';
				}
			} else {
				$json['error'] = 'Warning';
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	protected function validate($post) {
		if (!isset($post['category_description']['en-gb']['name'])) {
			return false;
		}
		
		return true;
	}
	
	protected function getCategories() {
		$query = $this->db->query("SELECT c.category_id, c.parent_id, cd.name FROM " . DB_PREFIX . "category c LEFT JOIN " . DB_PREFIX . "category_description cd ON (c.category_id = cd.category_id) LEFT JOIN " . DB_PREFIX . "category_to_store c2s ON (c.category_id = c2s.category_id) WHERE cd.language_id = '" . (int)$this->config->get('config_language_id') . "' AND c2s.store_id = '" . (int)$this->config->get('config_store_id') . "'  AND c.status = '1' ORDER BY c.category_id");

		return $query->rows;
	}
	
	protected function addCategory($data) {
		$this->db->query("INSERT INTO " . DB_PREFIX . "category SET parent_id = '" . (int)$data['parent_id'] . "', `top` = '" . (isset($data['top']) ? (int)$data['top'] : 0) . "', `column` = '" . (int)$data['column'] . "', sort_order = '" . (int)$data['sort_order'] . "', status = '" . (int)$data['status'] . "', date_modified = NOW(), date_added = NOW()");

		$category_id = $this->db->getLastId();

		if (isset($data['image'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "category SET image = '" . $this->db->escape($data['image']) . "' WHERE category_id = '" . (int)$category_id . "'");
		}

		foreach ($data['category_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "category_description SET category_id = '" . (int)$category_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "', description = '', meta_title = '" . $this->db->escape($value['meta_title']) . "', meta_description = '', meta_keyword = '" . $this->db->escape($value['meta_keyword']) . "'");
		}

		// MySQL Hierarchical Data Closure Table Pattern
		$level = 0;

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "category_path` WHERE category_id = '" . (int)$data['parent_id'] . "' ORDER BY `level` ASC");

		foreach ($query->rows as $result) {
			$this->db->query("INSERT INTO `" . DB_PREFIX . "category_path` SET `category_id` = '" . (int)$category_id . "', `path_id` = '" . (int)$result['path_id'] . "', `level` = '" . (int)$level . "'");

			$level++;
		}

		$this->db->query("INSERT INTO `" . DB_PREFIX . "category_path` SET `category_id` = '" . (int)$category_id . "', `path_id` = '" . (int)$category_id . "', `level` = '" . (int)$level . "'");

		if (isset($data['category_filter'])) {
			foreach ($data['category_filter'] as $filter_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_filter SET category_id = '" . (int)$category_id . "', filter_id = '" . (int)$filter_id . "'");
			}
		}

		if (isset($data['category_store'])) {
			foreach ($data['category_store'] as $store_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_to_store SET category_id = '" . (int)$category_id . "', store_id = '" . (int)$store_id . "'");
			}
		}
		
		// Set which layout to use with this category
		if (isset($data['category_layout'])) {
			foreach ($data['category_layout'] as $store_id => $layout_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "category_to_layout SET category_id = '" . (int)$category_id . "', store_id = '" . (int)$store_id . "', layout_id = '" . (int)$layout_id . "'");
			}
		}

		return $category_id;
	}
	
	protected function getLanguages() {
		$language_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "language ORDER BY sort_order, name");

		foreach ($query->rows as $result) {
			$language_data[$result['code']] = array(
				'language_id' => $result['language_id'],
				'name'        => $result['name'],
				'code'        => $result['code'],
				'locale'      => $result['locale'],
				'image'       => $result['image'],
				'directory'   => $result['directory'],
				'sort_order'  => $result['sort_order'],
				'status'      => $result['status']
			);
		}
		
		return $language_data;
	}
	
	protected function CURLLoad($url, $localFile) {
		$file = fopen($localFile, 'w');
		
		$curl = curl_init($url);

		if($curl === false) {
			return false;
		}
		
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_FILE, $file);
		
		$loadResult = curl_exec($curl);
		
		curl_close($curl);
		fclose($file);
		
		if($loadResult === false) {
			return false;
		}
		
		return true;
	}
}
