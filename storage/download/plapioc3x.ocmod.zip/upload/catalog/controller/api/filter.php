<?php
class ControllerApiFilter extends Controller {
	public function listFilters() {
		$json = array();

		if (!isset($this->session->data['api_id'])) {
			$json['error'] = 'You do not have permission to access the API!';
		} else {
			$input_json = file_get_contents('php://input');

			$post = json_decode($input_json, true);
			
			if (isset($post['filter_group_id'])) {
				$json['filters'] = $this->getFilters(array('filter_group_id' => $post['filter_group_id']));
				
				$json['success'] = 'Success';
			} else {
				$json['error'] = 'Warning';
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function listGroups() {
		$json = array();

		if (!isset($this->session->data['api_id'])) {
			$json['error'] = 'You do not have permission to access the API!';
		} else {
			$json['filter_groups'] = $this->getFilterGroups();
			
			$json['success'] = 'Success';
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function addFilter() {
		$json = array();
		
		if (!isset($this->session->data['api_id'])) {
			$json['error'] = 'You do not have permission to access the API!';
		} else {
			$input_json = file_get_contents('php://input');

			$post = json_decode($input_json, true);
			
			if ($this->validateFilter($post)) {
				$languages = $this->getLanguages();
			
				foreach ($languages as $language) {
					if (isset($post['filter_description'][$language['code']]['name'])) {
						$data['filter_description'][$language['language_id']]['name'] = $post['filter_description'][$language['code']]['name'];
					} else {
						$data['filter_description'][$language['language_id']]['name'] = $post['filter_description']['en-gb']['name'];
					}
				}
				
				if (isset($post['sort_order'])) {
					$data['sort_order'] = $post['sort_order'];
				} else {
					$data['sort_order'] = 0;
				}

				$filter_id = $this->addFilterProtected($post['filter_group_id'], $data);

				if ($filter_id) {
					$json['filter_id'] = $filter_id;
					$json['success'] = 'Success';
				} else {
					$json['error'] = 'Warning';
				}
			} else {
				$json['error'] = 'Warning';
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function addGroup() {
		$json = array();
		
		if (!isset($this->session->data['api_id'])) {
			$json['error'] = 'You do not have permission to access the API!';
		} else {
			$input_json = file_get_contents('php://input');

			$post = json_decode($input_json, true);
			
			if ($this->validateGroup($post)) {
				$languages = $this->getLanguages();
			
				foreach ($languages as $language) {
					if (isset($post['filter_group_description'][$language['code']]['name'])) {
						$data['filter_group_description'][$language['language_id']]['name'] = $post['filter_group_description'][$language['code']]['name'];
					} else {
						$data['filter_group_description'][$language['language_id']]['name'] = $post['filter_group_description']['en-gb']['name'];
					}
				}
				
				if (isset($post['sort_order'])) {
					$data['sort_order'] = $post['sort_order'];
				} else {
					$data['sort_order'] = 0;
				}

				$filter_group_id = $this->addFilterGroupProtected($data);

				if ($filter_group_id) {
					$json['filter_group_id'] = $filter_group_id;
					$json['success'] = 'Success';
				} else {
					$json['error'] = 'Warning';
				}
			} else {
				$json['error'] = 'Warning';
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	protected function validateFilter($post) {
		if (!isset($post['filter_description']['en-gb']['name'])) {
			return false;
		}
		if (!isset($post['filter_group_id'])) {
			return false;
		}
		
		return true;
	}
	
	protected function validateGroup($post) {
		if (!isset($post['filter_group_description']['en-gb']['name'])) {
			return false;
		}
		
		return true;
	}
	
	protected function getFilterGroups($data = array()) {
		$sql = "SELECT * FROM `" . DB_PREFIX . "filter_group` fg LEFT JOIN " . DB_PREFIX . "filter_group_description fgd ON (fg.filter_group_id = fgd.filter_group_id) WHERE fgd.language_id = '" . (int)$this->config->get('config_language_id') . "'";

		$query = $this->db->query($sql);

		return $query->rows;
	}
	
	protected function getFilters($data) {
		$sql = "SELECT *, (SELECT name FROM " . DB_PREFIX . "filter_group_description fgd WHERE f.filter_group_id = fgd.filter_group_id AND fgd.language_id = '" . (int)$this->config->get('config_language_id') . "') AS `group` FROM " . DB_PREFIX . "filter f LEFT JOIN " . DB_PREFIX . "filter_description fd ON (f.filter_id = fd.filter_id) WHERE fd.language_id = '" . (int)$this->config->get('config_language_id') . "'";

		if (!empty($data['filter_name'])) {
			$sql .= " AND fd.name LIKE '" . $this->db->escape($data['filter_name']) . "%'";
		}
		
		if (!empty($data['filter_group_id'])) {
			$sql .= " AND f.filter_group_id = '" . (int)$data['filter_group_id'] . "'";
		}

		$sql .= " ORDER BY f.sort_order ASC";

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}
	
	protected function addFilterGroupProtected($data) {
		$this->db->query("INSERT INTO `" . DB_PREFIX . "filter_group` SET sort_order = '" . (int)$data['sort_order'] . "'");

		$filter_group_id = $this->db->getLastId();

		foreach ($data['filter_group_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "filter_group_description SET filter_group_id = '" . (int)$filter_group_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "'");
		}

		return $filter_group_id;
	}
	
	protected function addFilterProtected($filter_group_id, $filter) {
		$this->db->query("INSERT INTO " . DB_PREFIX . "filter SET filter_group_id = '" . (int)$filter_group_id . "', sort_order = '" . (int)$filter['sort_order'] . "'");

		$filter_id = $this->db->getLastId();

		foreach ($filter['filter_description'] as $language_id => $filter_description) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "filter_description SET filter_id = '" . (int)$filter_id . "', language_id = '" . (int)$language_id . "', filter_group_id = '" . (int)$filter_group_id . "', name = '" . $this->db->escape($filter_description['name']) . "'");
		}

		return $filter_id;
	}
	
	protected function getLanguages() {
		$language_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "language ORDER BY sort_order, name");

		foreach ($query->rows as $result) {
			$language_data[$result['code']] = array(
				'language_id' => $result['language_id'],
				'name'        => $result['name'],
				'code'        => $result['code'],
				'locale'      => $result['locale'],
				'image'       => $result['image'],
				'directory'   => $result['directory'],
				'sort_order'  => $result['sort_order'],
				'status'      => $result['status']
			);
		}
		
		return $language_data;
	}
}
