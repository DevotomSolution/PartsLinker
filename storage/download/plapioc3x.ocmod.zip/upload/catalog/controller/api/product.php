<?php
class ControllerApiProduct extends Controller {
	public function add() {
		$json = array();
		
		if (!isset($this->session->data['api_id'])) {
			$json['error'] = 'You do not have permission to access the API!';
		} else {
			$input_json = file_get_contents('php://input');

			$post = json_decode($input_json, true);
			
			if ($this->validate($post)) {
				$languages = $this->getLanguages();
				
				foreach ($languages as $language) {
					if (isset($post['product_description'][$language['code']]['name']) and isset($post['product_description'][$language['code']]['description'])) {
						$data['product_description'][$language['language_id']]['name'] = $post['product_description'][$language['code']]['name'];
						$data['product_description'][$language['language_id']]['meta_title'] = $post['product_description'][$language['code']]['name'];
						$data['product_description'][$language['language_id']]['meta_keyword'] = $post['product_description'][$language['code']]['name'];
						$data['product_description'][$language['language_id']]['description'] = $post['product_description'][$language['code']]['description'];
					} else {
						$data['product_description'][$language['language_id']]['name'] = $post['product_description']['en-gb']['name'];
						$data['product_description'][$language['language_id']]['meta_title'] = $post['product_description']['en-gb']['name'];
						$data['product_description'][$language['language_id']]['meta_keyword'] = $post['product_description']['en-gb']['name'];
						$data['product_description'][$language['language_id']]['description'] = $post['product_description']['en-gb']['description'];
					}
				}

				$data['price'] = (float) $post['price'];
				
				if (isset($post['model'])) {
					$data['model'] = $post['model'];
				} else {
					$data['model'] = '';
				}
				
				if (isset($post['sku'])) {
					$data['sku'] = $post['sku'];
				} else {
					$data['sku'] = '';
				}
				
				if (isset($post['ean'])) {
					$data['ean'] = $post['ean'];
				} else {
					$data['ean'] = '';
				}
				
				if (isset($post['mpn'])) {
					$data['mpn'] = $post['mpn'];
				} else {
					$data['mpn'] = '';
				}
				
				if (isset($post['location'])) {
					$data['location'] = $post['location'];
				} else {
					$data['location'] = '';
				}

				$data['product_store'] =  array((int) $this->config->get('config_store_id'));

				if (isset($post['shipping'])) {
					$data['shipping'] = $post['shipping'];
				} else {
					$data['shipping'] = 1;
				}

				if (isset($post['tax_class_id'])) {
					$data['tax_class_id'] = $post['tax_class_id'];
				} else {
					$data['tax_class_id'] = 0;
				}

				if (isset($post['date_available'])) {
					$data['date_available'] = $post['date_available'];
				} else {
					$data['date_available'] = date('Y-m-d');
				}

				if (isset($post['quantity'])) {
					$data['quantity'] = $post['quantity'];
				} else {
					$data['quantity'] = 1;
				}

				if (isset($post['minimum'])) {
					$data['minimum'] = $post['minimum'];
				} else {
					$data['minimum'] = 1;
				}

				if (isset($post['subtract'])) {
					$data['subtract'] = $post['subtract'];
				} else {
					$data['subtract'] = 1;
				}

				if (isset($post['sort_order'])) {
					$data['sort_order'] = $post['sort_order'];
				} else {
					$data['sort_order'] = 1;
				}

				if (isset($post['stock_status_id'])) {
					$data['stock_status_id'] = $post['stock_status_id'];
				} else {
					$data['stock_status_id'] = 0;
				}

				if (isset($post['status'])) {
					$data['status'] = $post['status'];
				} else {
					$data['status'] = true;
				}

				if (isset($post['weight'])) {
					$data['weight'] = $post['weight'];
				} else {
					$data['weight'] = '';
				}

				if (isset($post['weight_class_id'])) {
					$data['weight_class_id'] = $post['weight_class_id'];
				} else {
					$data['weight_class_id'] = $this->config->get('config_weight_class_id');
				}

				if (isset($post['length'])) {
					$data['length'] = $post['length'];
				} else {
					$data['length'] = '';
				}

				if (isset($post['width'])) {
					$data['width'] = $post['width'];
				} else {
					$data['width'] = '';
				}

				if (isset($post['height'])) {
					$data['height'] = $post['height'];
				} else {
					$data['height'] = '';
				}

				if (isset($post['length_class_id'])) {
					$data['length_class_id'] = $post['length_class_id'];
				} else {
					$data['length_class_id'] = $this->config->get('config_length_class_id');
				}

				if (isset($post['manufacturer_id'])) {
					$data['manufacturer_id'] = $post['manufacturer_id'];
				} else {
					$data['manufacturer_id'] = 0;
				}

				if (isset($post['product_category'])) {
					$data['product_category'] = $post['product_category'];
				} else {
					$data['product_category'] = array();
				}

				if (isset($post['product_filter'])) {
					$data['product_filter'] = $post['product_filter'];
				} else {
					$data['product_filter'] = array();
				}
				
				if (isset($post['product_attribute'])) {
					$data['product_attribute'] = $post['product_attribute'];
				} else {
					$data['product_attribute'] = array();
				}
				
				if (!file_exists('image/catalog/product') and file_exists('image/catalog')) {
					mkdir('image/catalog/product');
				}
				
				$entities = array(' ');
				$replacements = array('%20');

				if (isset($post['image']) and file_exists('image/catalog/product')) {
					$pathinfo = pathinfo($post['image']);
				
					if ($pathinfo['extension'] === 'png' or $pathinfo['extension'] === 'jpg' or $pathinfo['extension'] === 'jpeg') {
						$fname = 'image/catalog/product/' . $pathinfo['basename'];
						
						if ($this->CURLLoad(str_replace($entities, $replacements, $post['image']), $fname)) {
							$data['image'] = 'catalog/product/' . $pathinfo['basename'];
						}
					}
				} 

				if (isset($post['product_image']) and is_array($post['product_image']) and file_exists('image/catalog/product')) {
					foreach ($post['product_image'] as $key => $image) {
						$pathinfo = pathinfo($image);
				
						if ($pathinfo['extension'] === 'png' or $pathinfo['extension'] === 'jpg' or $pathinfo['extension'] === 'jpeg') {
							$fname = 'image/catalog/product/' . $pathinfo['basename'];
							
							if ($this->CURLLoad(str_replace($entities, $replacements, $image), $fname)) {
								$data['product_image'][] = array('image' => 'catalog/product/' . $pathinfo['basename'], 'sort_order' => (int) $key);
							}
						}
					}
				}
				
				$product_id = $this->addProduct($data);
			
				if ($product_id) {
					$json['success'] = 'Success';
					$json['product_id'] = $product_id;
				} else {
					$json['error'] = 'Warning';
				}
			} else {
				$json['error'] = 'Warning';
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function edit() {
		$json = array();

		if (!isset($this->session->data['api_id'])) {
			$json['error'] = 'You do not have permission to access the API!';
		} else {
			$input_json = file_get_contents('php://input');

			$post = json_decode($input_json, true);
			
			$product_info = false;
			
			if (isset($post['product_id'])) {
				$this->load->model('catalog/product');
				
				$product_info = $this->model_catalog_product->getProduct($post['product_id']);
			}
			
			if ($product_info) {
				if (isset($post['product_description']['en-gb']['name']) and isset($post['product_description']['en-gb']['description'])) {
					$languages = $this->getLanguages();
					
					foreach ($languages as $language) {
						if (isset($post['product_description'][$language['code']]['name']) and isset($post['product_description'][$language['code']]['description'])) {
							$data['product_description'][$language['language_id']]['name'] = $post['product_description'][$language['code']]['name'];
							$data['product_description'][$language['language_id']]['meta_title'] = $post['product_description'][$language['code']]['name'];
							$data['product_description'][$language['language_id']]['meta_keyword'] = $post['product_description'][$language['code']]['name'];
							$data['product_description'][$language['language_id']]['description'] = $post['product_description'][$language['code']]['description'];
						} else {
							$data['product_description'][$language['language_id']]['name'] = $post['product_description']['en-gb']['name'];
							$data['product_description'][$language['language_id']]['meta_title'] = $post['product_description']['en-gb']['name'];
							$data['product_description'][$language['language_id']]['meta_keyword'] = $post['product_description']['en-gb']['name'];
							$data['product_description'][$language['language_id']]['description'] = $post['product_description']['en-gb']['description'];
						}
					}
				}
				
				if (isset($post['model'])) {
					$data['model'] = $post['model'];
				} else {
					$data['model'] = $product_info['model'];
				}
				
				if (isset($post['price'])) {
					$data['price'] = $post['price'];
				} else {
					$data['price'] = $product_info['price'];
				}
				
				if (isset($post['sku'])) {
					$data['sku'] = $post['sku'];
				} else {
					$data['sku'] = $product_info['sku'];
				}
				
				if (isset($post['mpn'])) {
					$data['mpn'] = $post['mpn'];
				} else {
					$data['mpn'] = $product_info['mpn'];
				}
				
				if (isset($post['ean'])) {
					$data['ean'] = $post['ean'];
				} else {
					$data['ean'] = $product_info['ean'];
				}
				
				if (isset($post['location'])) {
					$data['location'] = $post['location'];
				} else {
					$data['location'] = $product_info['location'];
				}
				
				if (isset($post['shipping'])) {
					$data['shipping'] = $post['shipping'];
				} else {
					$data['shipping'] = 1;
				}
				
				if (isset($post['tax_class_id'])) {
					$data['tax_class_id'] = $post['tax_class_id'];
				} else {
					$data['tax_class_id'] = $product_info['tax_class_id'];
				}
				
				if (isset($post['date_available'])) {
					$data['date_available'] = $post['date_available'];
				} else {
					$data['date_available'] = $product_info['date_available'];
				}
				
				if (isset($post['quantity'])) {
					$data['quantity'] = $post['quantity'];
				} else {
					$data['quantity'] = $product_info['quantity'];
				}
				
				if (isset($post['minimum'])) {
					$data['minimum'] = $post['minimum'];
				} else {
					$data['minimum'] = $product_info['minimum'];
				}
				
				if (isset($post['subtract'])) {
					$data['subtract'] = $post['subtract'];
				} else {
					$data['subtract'] = $product_info['subtract'];
				}
				
				if (isset($post['sort_order'])) {
					$data['sort_order'] = $post['sort_order'];
				} else {
					$data['sort_order'] = $product_info['sort_order'];
				}
				
				if (isset($post['stock_status_id'])) {
					$data['stock_status_id'] = $post['stock_status_id'];
				} else {
					$data['stock_status_id'] = 0;
				}

				if (isset($post['status'])) {
					$data['status'] = $post['status'];
				} else {
					$data['status'] = $product_info['status'];
				}
				
				if (isset($post['weight'])) {
					$data['weight'] = $post['weight'];
				} else {
					$data['weight'] = $product_info['weight'];
				}
				
				if (isset($post['weight_class_id'])) {
					$data['weight_class_id'] = $post['weight_class_id'];
				} else {
					$data['weight_class_id'] = $product_info['weight_class_id'];
				}
				
				if (isset($post['length'])) {
					$data['length'] = $post['length'];
				} else {
					$data['length'] = $product_info['length'];
				}
				
				if (isset($post['width'])) {
					$data['width'] = $post['width'];
				} else {
					$data['width'] = $product_info['width'];
				}
				
				if (isset($post['height'])) {
					$data['height'] = $post['height'];
				} else {
					$data['height'] = $product_info['height'];
				}
				
				if (isset($post['length_class_id'])) {
					$data['length_class_id'] = $post['length_class_id'];
				} else {
					$data['length_class_id'] = $product_info['length_class_id'];
				}
				
				if (isset($post['manufacturer_id'])) {
					$data['manufacturer_id'] = $post['manufacturer_id'];
				} else {
					$data['manufacturer_id'] = $product_info['manufacturer_id'];
				}

				if (isset($post['product_category'])) {
					$data['product_category'] = $post['product_category'];
				}

				if (isset($post['product_filter'])) {
					$data['product_filter'] = $post['product_filter'];
				}
				
				if (isset($post['product_attribute'])) {
					$data['product_attribute'] = $post['product_attribute'];
				}
				
				if (!file_exists('image/catalog/product') and file_exists('image/catalog')) {
					mkdir('image/catalog/product');
				}
				
				$entities = array(' ');
				$replacements = array('%20');

				if (isset($post['image']) and file_exists('image/catalog/product')) {
					$pathinfo = pathinfo($post['image']);
				
					if ($pathinfo['extension'] === 'png' or $pathinfo['extension'] === 'jpg' or $pathinfo['extension'] === 'jpeg') {
						$fname = 'image/catalog/product/' . $pathinfo['basename'];
						
						if (!file_exists($fname)) {
							if ($this->CURLLoad(str_replace($entities, $replacements, $post['image']), $fname)) {
								$data['image'] = 'catalog/product/' . $pathinfo['basename'];
							}
						} else {
							$data['image'] = 'catalog/product/' . $pathinfo['basename'];
						}
					}
				}

				if (isset($post['product_image']) and is_array($post['product_image']) and file_exists('image/catalog/product')) {
					$data['product_image'] = array();
					
					$product_image = $this->model_catalog_product->getProductImages($post['product_id']);
					
					foreach ($post['product_image'] as $key => $image) {
						$pathinfo = pathinfo($image);
				
						if ($pathinfo['extension'] === 'png' or $pathinfo['extension'] === 'jpg' or $pathinfo['extension'] === 'jpeg') {
							$fname = 'image/catalog/product/' . $pathinfo['basename'];
							
							if (!file_exists($fname)) {
								if ($this->CURLLoad(str_replace($entities, $replacements, $image), $fname)) {
									$data['product_image'][] = array('image' => 'catalog/product/' . $pathinfo['basename'], 'sort_order' => (int) $key);
								}
							} else {
								$data['product_image'][] = array('image' => 'catalog/product/' . $pathinfo['basename'], 'sort_order' => (int) $key);
							}
						}
					}
				}
				
				$this->editProduct($post['product_id'], $data);
				
				$json['success'] = 'Success';
			} else {
				$json['error'] = 'Warning';
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function delete() {
		$json = array();	

		if (!isset($this->session->data['api_id'])) {
			$json['error'] = 'You do not have permission to access the API!';
		} else {
			$input_json = file_get_contents('php://input');

			$post = json_decode($input_json, true);
			
			if (isset($this->request->post['product_id'])) {
				$this->deleteProduct($post['product_id']);
				
				$json['success'] = 'Success';
			} else {
				$json['error'] = 'Warning';
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function status() {
		$json = array();

		if (!isset($this->session->data['api_id'])) {
			$json['error'] = 'You do not have permission to access the API!';
		} else {	
			$input_json = file_get_contents('php://input');

			$post = json_decode($input_json, true);
		
			if (isset($post['product_id']) and isset($post['status'])) {
				$this->db->query("UPDATE " . DB_PREFIX . "product SET status = '" . (int) $post['status'] . "' WHERE product_id = '" . (int) $post['product_id'] . "'");
				
				$json['success'] = 'Success';
			} else {
				$json['error'] = 'Warning';
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	protected function validate($post) {
		if (!isset($post['product_description']['en-gb']['name']) or !isset($post['product_description']['en-gb']['description'])) {
			return false;
		}
		
		if (empty($post['price'])) {
			return false;
		}
		
		return true;
	}
	
	protected function addProduct($data) {
		$this->db->query("INSERT INTO " . DB_PREFIX . "product SET model = '" . $this->db->escape($data['model']) . "', sku = '" . $this->db->escape($data['sku']) . "', ean = '" . $this->db->escape($data['ean']) . "', mpn = '" . $this->db->escape($data['mpn']) . "', location = '" . $this->db->escape($data['location']) . "', quantity = '" . (int)$data['quantity'] . "', minimum = '" . (int)$data['minimum'] . "', subtract = '" . (int)$data['subtract'] . "', stock_status_id = '" . (int)$data['stock_status_id'] . "', date_available = '" . $this->db->escape($data['date_available']) . "', manufacturer_id = '" . (int)$data['manufacturer_id'] . "', shipping = '" . (int)$data['shipping'] . "', price = '" . (float)$data['price'] . "', weight = '" . (float)$data['weight'] . "', weight_class_id = '" . (int)$data['weight_class_id'] . "', length = '" . (float)$data['length'] . "', width = '" . (float)$data['width'] . "', height = '" . (float)$data['height'] . "', length_class_id = '" . (int)$data['length_class_id'] . "', status = '" . (int)$data['status'] . "', tax_class_id = '" . (int)$data['tax_class_id'] . "', sort_order = '" . (int)$data['sort_order'] . "', date_added = NOW(), date_modified = NOW()");

		$product_id = $this->db->getLastId();

		if (isset($data['image'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "product SET image = '" . $this->db->escape($data['image']) . "' WHERE product_id = '" . (int)$product_id . "'");
		}

		foreach ($data['product_description'] as $language_id => $value) {
			$this->db->query("INSERT INTO " . DB_PREFIX . "product_description SET product_id = '" . (int)$product_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "', description = '" . $this->db->escape($value['description']) . "', tag = '', meta_title = '" . $this->db->escape($value['meta_title']) . "', meta_description = '', meta_keyword = '" . $this->db->escape($value['meta_keyword']) . "'");
		}

		if (isset($data['product_store'])) {
			foreach ($data['product_store'] as $store_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "product_to_store SET product_id = '" . (int)$product_id . "', store_id = '" . (int)$store_id . "'");
			}
		}

		if (isset($data['product_attribute'])) {
			foreach ($data['product_attribute'] as $product_attribute) {
				if ($product_attribute['attribute_id']) {
					// Removes duplicates
					$this->db->query("DELETE FROM " . DB_PREFIX . "product_attribute WHERE product_id = '" . (int)$product_id . "' AND attribute_id = '" . (int)$product_attribute['attribute_id'] . "'");

					foreach ($product_attribute['product_attribute_description'] as $language_id => $product_attribute_description) {
						$this->db->query("DELETE FROM " . DB_PREFIX . "product_attribute WHERE product_id = '" . (int)$product_id . "' AND attribute_id = '" . (int)$product_attribute['attribute_id'] . "' AND language_id = '" . (int)$language_id . "'");

						$this->db->query("INSERT INTO " . DB_PREFIX . "product_attribute SET product_id = '" . (int)$product_id . "', attribute_id = '" . (int)$product_attribute['attribute_id'] . "', language_id = '" . (int)$language_id . "', text = '" .  $this->db->escape($product_attribute_description['text']) . "'");
					}
				}
			}
		}

		if (isset($data['product_image'])) {
			foreach ($data['product_image'] as $product_image) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "product_image SET product_id = '" . (int)$product_id . "', image = '" . $this->db->escape($product_image['image']) . "', sort_order = '" . (int)$product_image['sort_order'] . "'");
			}
		}

		if (isset($data['product_category'])) {
			foreach ($data['product_category'] as $category_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "product_to_category SET product_id = '" . (int)$product_id . "', category_id = '" . (int)$category_id . "'");
			}
		}

		if (isset($data['product_filter'])) {
			foreach ($data['product_filter'] as $filter_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "product_filter SET product_id = '" . (int)$product_id . "', filter_id = '" . (int)$filter_id . "'");
			}
		}
		
		if (isset($data['product_category']) and isset($data['product_filter'])) {
			foreach ($data['product_category'] as $category_id) {
				foreach ($data['product_filter'] as $filter_id) {
					$this->db->query("INSERT IGNORE INTO " . DB_PREFIX . "category_filter SET category_id = '" . (int) $category_id . "', filter_id = '" . (int) $filter_id . "'");
				}
			}
		}

		return $product_id;
	}
	
	protected function editProduct($product_id, $data) {
		$this->db->query("UPDATE " . DB_PREFIX . "product SET model = '" . $this->db->escape($data['model']) . "', sku = '" . $this->db->escape($data['sku']) . "', ean = '" . $this->db->escape($data['ean']) . "', mpn = '" . $this->db->escape($data['mpn']) . "', location = '" . $this->db->escape($data['location']) . "', quantity = '" . (int)$data['quantity'] . "', minimum = '" . (int)$data['minimum'] . "', subtract = '" . (int)$data['subtract'] . "', stock_status_id = '" . (int)$data['stock_status_id'] . "', date_available = '" . $this->db->escape($data['date_available']) . "', manufacturer_id = '" . (int)$data['manufacturer_id'] . "', shipping = '" . (int)$data['shipping'] . "', price = '" . (float)$data['price'] . "', weight = '" . (float)$data['weight'] . "', weight_class_id = '" . (int)$data['weight_class_id'] . "', length = '" . (float)$data['length'] . "', width = '" . (float)$data['width'] . "', height = '" . (float)$data['height'] . "', length_class_id = '" . (int)$data['length_class_id'] . "', status = '" . (int)$data['status'] . "', tax_class_id = '" . (int)$data['tax_class_id'] . "', sort_order = '" . (int)$data['sort_order'] . "', date_modified = NOW() WHERE product_id = '" . (int)$product_id . "'");

		if (isset($data['image'])) {
			$this->db->query("UPDATE " . DB_PREFIX . "product SET image = '" . $this->db->escape($data['image']) . "' WHERE product_id = '" . (int)$product_id . "'");
		}
		
		if (isset($data['product_description'])) {
			$this->db->query("DELETE FROM " . DB_PREFIX . "product_description WHERE product_id = '" . (int)$product_id . "'");

			foreach ($data['product_description'] as $language_id => $value) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "product_description SET product_id = '" . (int)$product_id . "', language_id = '" . (int)$language_id . "', name = '" . $this->db->escape($value['name']) . "', description = '" . $this->db->escape($value['description']) . "', tag = '', meta_title = '" . $this->db->escape($value['meta_title']) . "', meta_description = '', meta_keyword = '" . $this->db->escape($value['meta_keyword']) . "'");
			}
		}

		if (isset($data['product_attribute'])) {
			$this->db->query("DELETE FROM " . DB_PREFIX . "product_attribute WHERE product_id = '" . (int)$product_id . "'");
			
			foreach ($data['product_attribute'] as $product_attribute) {
				if ($product_attribute['attribute_id']) {
					// Removes duplicates
					$this->db->query("DELETE FROM " . DB_PREFIX . "product_attribute WHERE product_id = '" . (int)$product_id . "' AND attribute_id = '" . (int)$product_attribute['attribute_id'] . "'");

					foreach ($product_attribute['product_attribute_description'] as $language_id => $product_attribute_description) {
						$this->db->query("INSERT INTO " . DB_PREFIX . "product_attribute SET product_id = '" . (int)$product_id . "', attribute_id = '" . (int)$product_attribute['attribute_id'] . "', language_id = '" . (int)$language_id . "', text = '" .  $this->db->escape($product_attribute_description['text']) . "'");
					}
				}
			}
		}

		if (isset($data['product_image'])) {
			$this->db->query("DELETE FROM " . DB_PREFIX . "product_image WHERE product_id = '" . (int)$product_id . "'");
			
			foreach ($data['product_image'] as $product_image) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "product_image SET product_id = '" . (int)$product_id . "', image = '" . $this->db->escape($product_image['image']) . "', sort_order = '" . (int)$product_image['sort_order'] . "'");
			}
		}

		if (isset($data['product_category'])) {
			$this->db->query("DELETE FROM " . DB_PREFIX . "product_to_category WHERE product_id = '" . (int)$product_id . "'");
			
			foreach ($data['product_category'] as $category_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "product_to_category SET product_id = '" . (int)$product_id . "', category_id = '" . (int)$category_id . "'");
			}
		}

		if (isset($data['product_filter'])) {
			$this->db->query("DELETE FROM " . DB_PREFIX . "product_filter WHERE product_id = '" . (int)$product_id . "'");
			
			foreach ($data['product_filter'] as $filter_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "product_filter SET product_id = '" . (int)$product_id . "', filter_id = '" . (int)$filter_id . "'");
			}
		}
		
		if (isset($data['product_category']) and isset($data['product_filter'])) {
			foreach ($data['product_category'] as $category_id) {
				foreach ($data['product_filter'] as $filter_id) {
					$this->db->query("INSERT IGNORE INTO " . DB_PREFIX . "category_filter SET category_id = '" . (int) $category_id . "', filter_id = '" . (int) $filter_id . "'");
				}
			}
		}
	}
	
	protected function deleteProduct($product_id) {
		$this->db->query("DELETE FROM " . DB_PREFIX . "product WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_attribute WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_description WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_filter WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_image WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_option WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_option_value WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_related WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_related WHERE related_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_reward WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_special WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_to_category WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_to_download WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_to_layout WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_to_store WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "product_recurring WHERE product_id = " . (int)$product_id);
		$this->db->query("DELETE FROM " . DB_PREFIX . "review WHERE product_id = '" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "seo_url WHERE query = 'product_id=" . (int)$product_id . "'");
		$this->db->query("DELETE FROM " . DB_PREFIX . "coupon_product WHERE product_id = '" . (int)$product_id . "'");
	}
	
	protected function getLanguages() {
		$language_data = array();

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "language ORDER BY sort_order, name");

		foreach ($query->rows as $result) {
			$language_data[$result['code']] = array(
				'language_id' => $result['language_id'],
				'name'        => $result['name'],
				'code'        => $result['code'],
				'locale'      => $result['locale'],
				'image'       => $result['image'],
				'directory'   => $result['directory'],
				'sort_order'  => $result['sort_order'],
				'status'      => $result['status']
			);
		}
		
		return $language_data;
	}
	
	protected function CURLLoad($url, $localFile) {
		$file = fopen($localFile, 'w');
		
		$curl = curl_init($url);

		if($curl === false) {
			return false;
		}
		
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_FILE, $file);
		
		$loadResult = curl_exec($curl);
		
		curl_close($curl);
		fclose($file);
		
		if($loadResult === false) {
			return false;
		}
		
		return true;
	}
}
