<?php
class ControllerApiOrders extends Controller {
	public function get() {
		$json = array();

		if (!isset($this->session->data['api_id'])) {
			$json['error'] = 'You do not have permission to access the API!';
		} else {
			$input_json = file_get_contents('php://input');

			$post = json_decode($input_json, true);
			
			if (isset($post['date_modified'])) {
				$this->load->model('checkout/order');
				$this->load->model('localisation/country');
				
				$filter_data = array(
					'filter_date_modified' => $post['date_modified']
				);
				
				if (isset($post['limit'])) {
					$filter_data['start'] = 0;
					$filter_data['limit'] = $post['limit'];
				}
				
				$orders = $this->getOrders($filter_data);
				
				foreach ($orders as $order) {
					$order['products'] = $this->model_checkout_order->getOrderProducts($order['order_id']);
					$order['totals'] = $this->model_checkout_order->getOrderTotals($order['order_id']);
					
					$order['shipping_country_code'] = $this->model_localisation_country->getCountry($order['shipping_country_id'])['iso_code_2'];
					
					if (in_array($order['order_status_id'], $this->config->get('config_complete_status'))) {
						$order['status'] = 'complete';
					} elseif ($order['order_status_id'] == $this->config->get('config_fraud_status_id')) {
						$order['status'] = 'fraud';
					} else {
						$order['status'] = 'processing';
					}
					
					$json['orders'][] = $order;
					$json['success'] = 'Success';
				}
			} else {
				$json['error'] = 'Warning';
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	private function getOrders($data = array()) {
		$sql = "SELECT * FROM `" . DB_PREFIX . "order` o";

		$sql .= " WHERE o.order_status_id > '0'";

		if (!empty($data['filter_order_id'])) {
			$sql .= " AND o.order_id = '" . (int)$data['filter_order_id'] . "'";
		}

		if (!empty($data['filter_customer'])) {
			$sql .= " AND CONCAT(o.firstname, ' ', o.lastname) LIKE '%" . $this->db->escape($data['filter_customer']) . "%'";
		}

		if (!empty($data['filter_date_added'])) {
			$sql .= " AND o.date_added > '" . $this->db->escape($data['filter_date_added']) . "'";
		}

		if (!empty($data['filter_date_modified'])) {
			$sql .= " AND o.date_modified > '" . $this->db->escape($data['filter_date_modified']) . "'";
		}

		if (!empty($data['filter_total'])) {
			$sql .= " AND o.total = '" . (float)$data['filter_total'] . "'";
		}

		$sort_data = array(
			'o.order_id',
			'customer',
			'order_status',
			'o.date_added',
			'o.date_modified',
			'o.total'
		);

		if (isset($data['sort']) && in_array($data['sort'], $sort_data)) {
			$sql .= " ORDER BY " . $data['sort'];
		} else {
			$sql .= " ORDER BY o.date_modified";
		}

		if (isset($data['order']) && ($data['order'] == 'DESC')) {
			$sql .= " DESC";
		} else {
			$sql .= " ASC";
		}

		if (isset($data['start']) || isset($data['limit'])) {
			if ($data['start'] < 0) {
				$data['start'] = 0;
			}

			if ($data['limit'] < 1) {
				$data['limit'] = 20;
			}

			$sql .= " LIMIT " . (int)$data['start'] . "," . (int)$data['limit'];
		}

		$query = $this->db->query($sql);

		return $query->rows;
	}
}