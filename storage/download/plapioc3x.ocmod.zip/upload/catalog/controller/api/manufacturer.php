<?php
class ControllerApiManufacturer extends Controller {
	public function list() {
		$json = array();

		if (!isset($this->session->data['api_id'])) {
			$json['error'] = 'You do not have permission to access the API!';
		} else {
			$this->load->model('catalog/manufacturer');
			
			$json['manufacturers'] = $this->model_catalog_manufacturer->getManufacturers();
			
			$json['success'] = 'Success';
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	public function add() {
		$json = array();

		if (!isset($this->session->data['api_id'])) {
			$json['error'] = 'You do not have permission to access the API!';
		} else {
			$input_json = file_get_contents('php://input');

			$post = json_decode($input_json, true);
			
			if ($this->validate($post)) {
				$data['name'] = $post['name'];
			
				if (isset($post['sort_order'])) {
					$data['sort_order'] = $post['sort_order'];
				} else {
					$data['sort_order'] = 1;
				}
				
				$data['manufacturer_store'] = array((int) $this->config->get('config_store_id'));
				
				$manufacturer_id = $this->addManufacturer($data);
				
				if ($manufacturer_id) {
					$json['manufacturer_id'] = $manufacturer_id;
					$json['success'] = 'Success';
				} else {
					$json['error'] = 'Warning';
				}
				
				$this->cache->delete('manufacturer');
			} else {
				$json['error'] = 'Warning';
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}
	
	protected function validate($post) {
		if (!isset($post['name'])) {
			return false;
		}
		
		return true;
	}
	
	protected function addManufacturer($data) {
		$this->db->query("INSERT INTO " . DB_PREFIX . "manufacturer SET name = '" . $this->db->escape($data['name']) . "', sort_order = '" . (int)$data['sort_order'] . "'");

		$manufacturer_id = $this->db->getLastId();
		
		if (isset($data['manufacturer_store'])) {
			foreach ($data['manufacturer_store'] as $store_id) {
				$this->db->query("INSERT INTO " . DB_PREFIX . "manufacturer_to_store SET manufacturer_id = '" . (int)$manufacturer_id . "', store_id = '" . (int)$store_id . "'");
			}
		}

		return $manufacturer_id;
	}
}
